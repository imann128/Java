import java.util.Scanner;

public class MainClass {
    public static void main (String[] args) {
        // As AtmOperationinterface provides an interface and AtmOperationInterfaceImpl provides it's functionality
        AtmOperationInterface operation = new AtmOperationInterfaceImpl();
        // Hardcoded atmNumber1 and atmPin1 for access validation
        int atmNumber1 = 12345;
        int atmPin1 = 123;
        // Input
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to ATM Machine");
        System.out.println("Enter the ATM number ");
        int atmNumber = scanner.nextInt();
        System.out.println("Enter the ATM pin ");
        int atmPin = scanner.nextInt();
        // if credentials match and access is provided
        if ((atmNumber == atmNumber1) && (atmPin == atmPin1)){
            while(true) {
            System.out.println("1.View Available Balance\n2.Withdraw Amount.\n3.Deposit Amount\n4.View Mini-Statements\n5.Exit");
            System.out.println("Choose an option: ");
            int choice = scanner.nextInt();
            if (choice == 1){                    
                operation.viewBalance();   // user can view balance with 1 option
            }
            else if (choice == 2){
                System.out.println("Enter the amount to withdraw: ");
                double withdrawAmount = scanner.nextDouble(); // operation object allows to access methods in the AtmoperationInterfaceImpl
                operation.withdrawAmount(withdrawAmount);  // user can withdraw amount
            }
             
            else if (choice == 3){
                System.out.println("Enter amount to deposit");
                double depositAmount = scanner.nextDouble();
                operation.depositAmount(depositAmount);   // user can deposit amount
            }
             
            else if (choice == 4){
                operation.viewMiniStatement();  // user can view mini-statememt
            }
             
            else if (choice == 5){
                System.out.println("Collect your ATM Card\n Thank you for using the ATM Machine");
                System.exit(0);  // to exit the application
            } 
            else {
                 System.out.println("Please enter the correct choice."); // if user does not eneter correct information
            }
            }
        } 
     
    }
} 
