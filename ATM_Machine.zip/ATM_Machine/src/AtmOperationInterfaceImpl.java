import java.util.Map; // Importing the Map interface
import java.util.HashMap; // Importing the Hashmap class

// Implementation of class AtmOperationInterface
public class AtmOperationInterfaceImpl implements AtmOperationInterface{
    ATM atm = new ATM(); // Object of ATM class
    Map<Double,String> ministat = new HashMap<>();  // For key-value pairs
    
    
// Method to view balance    
    @Override
    public void viewBalance(){
        System.out.println("Available Balance is: " + atm.getBalance());
    }

// Method to withdraw cash    
    @Override
    public void withdrawAmount(double withdrawAmount) {
        // condition to prevent invalid inputs
         if (withdrawAmount <= atm.getBalance()){
        // a method from hashmap that allows to generate mini-statement     
         ministat.put(withdrawAmount," Amount withdrawn");
         System.out.println(withdrawAmount+ " Amount withdrawn successfully!");
         // setBalance method to view balance after withdrawing money
         atm.setBalance(atm.getBalance()-withdrawAmount);
         viewBalance();
         } else {
         System.out.println("Invalid request!");  // if user exceeds current balance
         }
    }
    
    // Method to deposit balance
    @Override
    public void depositAmount(double depositAmount) {
        // a method from hashmap that allows to generate key-value pairs for min-statement
        ministat.put(depositAmount," Amount deposited");
        System.out.println(depositAmount+ " Deposited Successfully");
        // new balance is deposit amount + current balance
        atm.setBalance(atm.getBalance()+depositAmount);
        viewBalance();
    }
    
    @Override
    public void viewMiniStatement(){
        // generate min-statement by print the value for example 1000 and the statement i.e 1000.0 withdrawn 2000.0 deposited
        for (Map.Entry<Double, String> m:ministat.entrySet()) {
            System.out.println(m.getKey()+ ""+m.getValue());
        }
    }
}
