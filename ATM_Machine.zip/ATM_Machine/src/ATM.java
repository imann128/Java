
class ATM {
    // Instance variables
    private double balance;
    private double depositAmount;
    private double withdrawAmount;
    
    // Default constructor
    public ATM() {
    
    }
    
    public double getBalance() {
        return balance;
    }
    
    public double getDepositAmount() {
        return depositAmount;
    }
    
    public double getWithdrawAmount() {
        return withdrawAmount;
    }
    
    public double setBalance(double balance) {
        this.balance = balance;
        return balance;
    }
    
    public double setDepositAmount(double depositAmount) {
            this.depositAmount = depositAmount;
            return depositAmount;
    }
    
     public double setWithdrawAmount(double withdrawAmount) {
            this.withdrawAmount = withdrawAmount;
            return withdrawAmount;
    }
    
    
}

