// Interface class provides an interface for methods not functionality 
public interface AtmOperationInterface {
    public void viewBalance();
    public void withdrawAmount(double withdrawAmount);
    public void depositAmount(double depositAmount);
    public void viewMiniStatement();
}
